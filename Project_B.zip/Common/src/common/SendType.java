package common;

public enum SendType {
sendfile,requestmessage, sendping, PingResponse, RequestFile, SendRequiredFile
}
