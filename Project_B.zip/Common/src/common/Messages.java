package common;

public enum Messages {
	GetIPAddresses,
	BroadCast,
	Disconnected, 
	NumberOfConnectedClient,
	DH_Key, FileName_FileChunks,
	SendId, sss, RequestPort,
	CheckPort, hhh, RequestPortInBroadCast,
	GetHistory, FileData,  ClientsPerformance, GETDATA, UpdateServer
}
