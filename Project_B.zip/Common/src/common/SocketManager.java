package common;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.Files;
import java.util.concurrent.Semaphore;
public class SocketManager implements Runnable {
    public String host;
    public int port;
    public String path;
    public Socket clientSocket;
    public int LocalPort;
    public int number;
    public boolean ForShare;
    private SendType type;
     public static Semaphore semaphoreRequest= new Semaphore(0);
     public static Semaphore semaphoreSend= new Semaphore(0);
    public SocketManager(String host, int port, int LocalPort) {
        this.host = host;
        this.port = port;
        this.LocalPort=LocalPort;
    }
    
    public synchronized void sendFile(SendType type,String path,int number,boolean ForShare) throws InterruptedException {
		 this.path=path;
		 this.type=type;
		 this.number=number;
		 this.ForShare=ForShare;
		 notifyAll();
	}

	public void setPath(String path) {
		this.path = path;
	}
	public void run() {
		try {
			 clientSocket = new Socket();
            // Specify the remote server address and port to connect to
              // client2's IP address
            clientSocket= new Socket(host,port);
            
            System.out.println("socket manager "+clientSocket.toString());

           
 			//socket = new Socket(host, port);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
            while (true) {
                synchronized (this) {
                    // Wait for a file to be set
                    while (path == null) {
                        wait();
                    }
                    if(type.equals(SendType.sendfile))
                    {        
                    ObjectOutputStream oos = null;
                    oos = new ObjectOutputStream(clientSocket.getOutputStream());
                    File file=new File(path);
                    byte[] buffer = new byte[1024];
                    buffer=Files.readAllBytes(file.toPath());
                    FilePacket filePacket = new FilePacket(file,buffer,number,ForShare);
                     oos.writeObject(filePacket);
                    semaphoreSend.release();
                    path = null;
                    
                    }
                    else if(type.equals(SendType.requestmessage)) {
                    	ObjectOutputStream oos = null;
                        oos = new ObjectOutputStream(clientSocket.getOutputStream());
                         oos.writeObject(path);
                    }
                    else if(type.equals(SendType.sendping))
                    {
                    	 
                    	 ObjectOutputStream oos = null;
                    	 oos = new ObjectOutputStream(clientSocket.getOutputStream());
                    	 oos.writeObject(path);
                    	 System.out.println("im sending the ping");
                    }
                    else if(type.equals(SendType.PingResponse))
                    {
                    	 ObjectOutputStream oos = null;
                    	 oos = new ObjectOutputStream(clientSocket.getOutputStream());
                    	 oos.writeObject(path);
                    	
                    }
                    else if(type.equals(SendType.RequestFile)) {
                     ObjectOutputStream oos = null;
                     RequiredFile RequiredFile=new RequiredFile(path,number);
                   	 oos = new ObjectOutputStream(clientSocket.getOutputStream());
                   	 System.out.println("request to get the file ");
                   	 oos.writeObject(RequiredFile);
                   	 semaphoreRequest.release();

                    }
                    /**
                    FileInputStream fileInputStream = new FileInputStream(file);
                    OutputStream outputStream = socket.getOutputStream();
                    System.out.println("sending file");
                    // Send the path of the file to Client2
                    String filePath = file.getAbsolutePath();
                    byte[] pathBytes = filePath.getBytes();
                    outputStream.write(pathBytes);
                    outputStream.flush();

                    System.out.println("sending data");
                    // Send the contents of the file to Client2
                    int bytesRead;
                    while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, bytesRead);
                    }
                    System.out.println("sending completed ");
                    outputStream.flush();
                    **/
                    path = null;
                
                
                    
                    
                      
                    
                }
                }
		}catch (InterruptedException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
}