package common;
import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;

public class SHA256HashOfFile {
    public static String SHA256HashOfFile(String path) throws Exception {
        File file = new File(path);

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        FileInputStream fis = new FileInputStream(file);

        byte[] buffer = new byte[1024];
        int n = 0;
        while ((n = fis.read(buffer)) != -1) {
            digest.update(buffer, 0, n);
        }
        fis.close();

        byte[] hash = digest.digest();

        // Convert byte array to a string of hexadecimal values
        StringBuilder result = new StringBuilder();
        for (byte b : hash) {
            result.append(String.format("%02x", b));
        }

        System.out.println("SHA-256 hash of " + file.getName() + ": " + result.toString());
		return result.toString();
    }
}
